<?php
	session_start();
	require('connection.php');


?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>PHP with MySQL : Advanced : Wall</title>
	<meta name="keywords" content="">
	<meta name="description" content="">
	<link rel="stylesheet" type="text/css" href="global.css">
</head>
<body>
<?php include_once("analyticstracking.php") ?>
<div class="container">
	<div class="header">
		<h2>Coding Dojo Wall</h2>
	</div>
	<div class="content">
		<div class="success">
			<h1>Registration Successful!</h1>
			<p>Click <a href='wall.php'>here</a> to go to the app.</p>
		</div>
	</div>
</div>
</body>
</html>